#include<iostream>
using namespace std;

int main(){


String ch = "Kathmandu";

 cout<<ch.charAt(2);
 return 0;
}
