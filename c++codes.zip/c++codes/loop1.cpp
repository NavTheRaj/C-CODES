#include<iostream>
using namespace std;

int main(){

	
	for(;;)
	{
	int i=109;
i=i%10;	
		cout<<i<<endl;
	}
}
