#include<iostream>
using namespace std;
int main(){
        int num=0,daynum,custid,date,i,j,k,l;
        cout<<"Welcome to the bhatvateni supermarket"<<endl<<"--------------------------"<<endl<<"--------------------------"<<endl;
        cout<<"Enter date: ";
        cin>>date;
        cout<<"Enter the number of customers: ";
        cin>>num;

        for(i=0;i<num;i++)
        {


                cout<<endl<<"Customer id: ";
                cin>>custid;
                cout<<"Enter the number of days: ";
            cin>>daynum;
            int days[daynum],price[daynum]={},unitprice[daynum]={},totalprice[num]={},total=0,discount[num],priceafterdis[num];
                cout<<"Please enter the "<<daynum<<" days stock info"<<endl<<"-------------------"<<endl<<"-------------------"<<endl;
                for(j=0;j<daynum;j++){
                cout<<endl<<"Day["<<j+1<<"] charge: ";
                cin>>price[j];
                cout<<"Unit Price["<<j+1<<"]: ";
                cin>>unitprice[j];
                totalprice[i]+=price[j]*unitprice[j];
        //      total=totalprice[j]+total;
                cout<<endl<<"Day["<<j+1<<"] total charge: "<<totalprice[i]<<endl;
        }



//      cout<<"Customer id: "<<custid;

                if(totalprice[i]>600)
                {
                discount[i]=0.25*totalprice[i];
                priceafterdis[i]=totalprice[i]-discount[i];
                }
                else if(totalprice[i]>200 && totalprice[i]<400){
                                discount[i]=0.15*totalprice[i];
                priceafterdis[i]=totalprice[i]-discount[i];
                }
                else if(totalprice[i]>100 && totalprice[i]<200){
                        discount[i]=0.05*totalprice[i];
                        priceafterdis[i]=totalprice[i]-discount[i];
                }
                else{
                                discount[i]=0;
                                priceafterdis[i]=totalprice[i]-discount[i];

                }

                cout<<endl;
                cout<<"Total price: "<<totalprice[i]<<endl;
                cout<<"Discount price: "<<discount[i]<<endl;
                cout<<"Price after discount: "<<priceafterdis[i]<<endl;
        }

return 0;

}
                
