#include<iostream>
using namespace std;
int main()
{
        int day,c_id,totalprice=0,priceafterdis=0,i,j,num;
        float D=0;
        cout<<"Enter the number of customer :";
        cin>>num;
        cout<<"Enter the days :";
        cin>>day;

        int days[day],unitprice[day],date,totalcharge[day];

        cout<<"Enter " <<day<<" stock info"<<endl;
        cout<<"----------------------"<<endl<<"-----------------------"<<endl;
        for(j=0;j<num;j++)
        {
        cout<<"Enter the customer id :";
        cin>>c_id;
        cout<<"Enter the date :";
        cin>>date;
        cout<<endl;
        for(i=0;i<day;i++)
        {
        cout<<"day["<<(i+1)<<"]=";
        cin>>days[i];
        cout<<"unit price["<<(i+1)<<"]=";
        cin>>unitprice[i];
        totalcharge[i]=days[i]*unitprice[i];
         totalprice=totalprice+totalcharge[i];

        cout<<endl<<"Day "<<(i+1)<<" charges="<<totalprice<<endl;
}


        if(totalcharge[i]>601)
        {
                D=totalcharge[i]*0.25;
                priceafterdis=totalcharge[i]-totalcharge[i]*0.25;
        }
        else if(totalcharge[i]>401 && totalcharge[i]<601){
                D=totalcharge[i]*0.15;
                priceafterdis=totalcharge[i]-totalcharge[i]*0.15;
        }
        else if(totalcharge[i]>201 && totalcharge[i]<401)
        {       D= totalcharge[i]*0.10;
                priceafterdis=totalcharge[i]-totalcharge[i]*0.10;
        }
        else{
                D=0;
        }


        cout<<"Total charges :"<<totalprice<<endl;
        cout<<"Discounted price :"<<D<<endl;

        cout<<"Price after discount :"<<priceafterdis<<endl;
        return 0;
        }
}
      






