#include<iostream>
#include<string>
using namespace std;

char name;
int main(){
	cout<<"Enter the name of the student: ";
	cin>>name;
switch(name){

	case 'R':
		cout<<"Gender:Male"<<endl;
		cout<<"Address:Park avenue"<<endl;
		cout<<"Phone no: 986987897"<<endl;
		break;

	case 'H':
		    cout<<"Gender:Male"<<endl;
                cout<<"Address:Park avenue"<endl;
                cout<<"Phone no: 9869552144"<<endl;
                break;

	case 'S':
                    cout<<"Gender:FeMale"<<endl;
                cout<<"Address:Park avenu20e"<<endl;
                cout<<"Phone no: 986958785"<<endl;
                break;
		  default:cout<<"Invalid input"<<endl;
}
return 0;
}





