#include<iostream>
using namespace std;
int main(){
cout<<"\n Hello World \n ";
return 0;
}
