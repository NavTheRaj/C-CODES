#include<iostream>
#include<iomanip>
using namespace std;
int main(){
double x=12.4,y=456.0;
cout<<setprecision(5)<<showpoint<<x<<endl;
cout<<setprecision(7)<<y<<endl;
}
