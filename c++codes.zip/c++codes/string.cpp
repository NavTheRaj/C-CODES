#include<iostream>
#include<string>
using namespace std;
char name;
int main(){
	cout<<"Enter your favorite movie: ";
	cin>>name;
	cout<<"Your favorite movie: "<<name<<endl;
	return 0;
}
