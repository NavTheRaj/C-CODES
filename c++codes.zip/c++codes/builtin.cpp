#include<iostream>
#include<cmath>
using namespace std;

int main(){

cout<<abs(3.5)<<endl;//makes any  umber to positive
cout<<abs(-3.5)<<endl;
cout<<ceil(59.76)<<endl;//take to just upper number floor() to lower one
cout<<log(5)<<endl;
cout<<fmod(10,3)<<endl;//10%3==? gives the result
cout<<fmod(10.5,3)<<endl;
return 0;
}
