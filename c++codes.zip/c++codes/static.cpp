#include<iostream>
#include<iomanip>
#include<string>
using namespace std;

int main(){
	char ch,value;
	int total;
	total=(6-3)*(2+7)/3;
	cout<<"The total is :"<<total<<endl;

	cin.get(ch);

	int a=5,b=12;

	double x=3.4,z=9.1;

	cout<<b/a<<endl<<x*a<<endl<<a*x<<endl
		<<static_cast<double>(b/a)<<endl
		<<static_cast<double>(b)/a<<endl
		<<b/static_cast<double>(a)<<endl
		<<static_cast<double>(b)/static_cast<double>(a)<<endl
		<<b/ static_cast<int>(x)<<endl
		<<static_cast<int>(x)*static_cast<int>(z)<<endl
		<<static_cast<int>(x*z)<<endl
		<<static_cast<double>(static_cast<int>(x)*static_cast<int>(z))<<endl;

				ch=cin.get();
				cout<<"Are you sure you want to go to next section?"<<endl<<"Type Y or N"<<endl;
				cin>>value;
                                cin.ignore();
				if(value=='Y' || value=='y'){
				cout<<endl<<"Press enter and you are ready to go"<<endl;
				ch=cin.get();
			        
				string name,city;
				bool result;
				name="Rama";
				city="sama";
				cout<<name+city<<endl;
				cout<<endl<<"Length of name is "<<name.length()<<endl;
				cout<<endl<<"Length of city is "<<city.length()<<endl;
				result=name>city;
				cout<<result<<endl;
				result=name!=city;
				cout<<result<<endl;
				result=name<city;
				cout<<result<<endl;

				cout<<"Enter your name"<<endl;
			//	cin>>name;

				getline(cin,name);//To display the name after space also.

				cout<<name<<endl;
				return 0;
				}
				else if(value=='N' || value=='n')
				{
					exit(0);
				}
				else{
					cout<<"Invalid choice"<<endl;
				}
}
