#include<iostream>
using namespace std;
int main()
{
        int day,c_id,totalprice,priceafterdis,i,j,D,num;
	cout<<"Enter the number of customer :"<<endl;
	cin>>num;
	cout<<"Enter the days :"<<endl;
	cin>>day;
	
	int days[day],unitprice[day],date,totalcharge[day];
	cout<<"Enter " <<day<<" stock info"<<endl;
	cout<<"----------------------"<<endl<<"-----------------------"<<endl;
        for(j=0;j<num;j++)
	{
	cout<<"Enter the customer id :";
	cin>>c_id;
	cout<<"Enter the date :";
	cin>>date;
	cout<<endl;
	for(i=0;i<day;i++)
	{
	cout<<"day["<<(i+1)<<"]=";
	cin>>days[i];
	cout<<"unit price["<<(i+1)<<"]=";
	cin>>unitprice[i];
        totalcharge[i]=days[i]*unitprice[i];
	 totalprice=totalprice+totalcharge[i];

	cout<<endl<<"Day"<<(i+1)<<"charges="<<totalprice<<endl;

	
	
	if(totalcharge[i]>600)
	{
                D=totalcharge[i]*0.25;
		priceafterdis=totalcharge[i]-totalcharge[i]*0.25;
	}
	else if(totalcharge[i]>400 && totalcharge[i]<600){
         	D=totalcharge[i]*0.15;
		priceafterdis=totalcharge[i]-totalcharge[i]*0.15;
	}
	else if(totalcharge[i]>200 && totalcharge[i]<400)
	{       D= totalcharge[i]*0.10;
		priceafterdis=totalcharge[i]-totalcharge[i]*0.10;
	}
	else{
		D=0;
	}	
	

	cout<<"Total charges :"<<totalprice<<endl;
	cout<<"Discounted price :"<<D<<endl;

	cout<<"Price after discount :"<<priceafterdis;
	return 0;
	}
	}

}

