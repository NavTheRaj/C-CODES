#include<iostream>
using namespace std;
void sortfun(int arr[])
{
        int i,j,temp1,temp2;
        for(int i=0;i<7;i++)
        {
                temp1=arr[i];
                for(int j=0;j<7;j++)
                {
                        if(temp1<arr[j])
                                temp1=arr[j];
                }
        }
        cout<<"Largest number is :"<<temp1<<endl;
}

int main()
{
	int arr[]={11,2,1,4,9,8,10};
	cout<<"Numbers are : ";
	for(int i=0;i<7;i++)
	{
		cout<<arr[i]<<"\t";
	}
	cout<<endl;
	sortfun(arr);
}


