#include<iostream>
using namespace std;
int main()
{
	char a='Z';
	char b=65;
	cout<<a<<'a'<<'Z'<<b<<endl;
	cout<<"The character (" <<'a' <<") has the value "<<static_cast<int>('a')<<endl;
	return 0;
}
