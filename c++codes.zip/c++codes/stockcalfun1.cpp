#include<fstream>       
#include<iostream>
#include<ctime>
using namespace std;

void calculate(int totalprice[],int custid[],int num);

int main(){
	fstream st;
       ofstream outfile;
       outfile.open("/home/nirvan/user1.txt",ios::app | ios::out);


        int num=0,daynum=0,date,i,j,k,l;
	outfile<<"Welcome to the bhatvateni supermarket"<<endl<<"--------------------------"<<endl<<"--------------------------"<<endl;
        cout<<"Welcome to the bhatvateni supermarket"<<endl<<"--------------------------"<<endl<<"--------------------------"<<endl;
        cout<<"Enter date: ";
	outfile<<"Date: ";
        cin>>date;
	st<<"hello";
	outfile<<date<<endl;
        cout<<"Enter the number of customers: ";
	outfile<<"Number of customers: ";
        cin>>num;
        outfile<<num<<endl;

	int totalprice[num]={0},custid[num];

       for(int i=0;i<num;i++)
       {
	        outfile<<"Customer id: ";
                cout<<endl<<"Customer id: ";
                cin>>custid[i];
		outfile<<custid[i]<<endl;
		outfile<<"Number of days: ";
                cout<<"Enter the number of days: ";
                cin>>daynum;
		outfile<<daynum<<endl;
                int days[daynum],price[daynum]={},unitprice[daynum]={};
                cout<<"Please enter the "<<daynum<<" days stock info"<<endl<<"-------------------"<<endl<<"-------------------"<<endl;
                outfile<<"The "<<daynum<<" days stock info"<<endl<<"-------------------"<<endl<<"-------------------"<<endl;
		for(j=0;j<daynum;j++){

                outfile<<endl<<"Day["<<j+1<<"] charge: ";
                cout<<endl<<"Day["<<j+1<<"] charge: ";
                cin>>price[j];
		outfile<<price[j];
                cout<<"Unit Price["<<j+1<<"]: ";
	        outfile<<"Unit Price["<<j+1<<"]: ";
                cin>>unitprice[j];
		outfile<<unitprice[j];
                totalprice[i] += price[j]*unitprice[j];
		outfile<<endl<<"Day["<<j+1<<"] total charge: "<<totalprice[i]<<endl;
                cout<<endl<<"Day["<<j+1<<"] total charge: "<<totalprice[i]<<endl;
		cout<<endl;
		outfile<<endl;
		}
	
	     
               

       }
               calculate(totalprice,custid,num);

               outfile.close();

return 0;
        
}
void calculate(int totalprice[],int custid[],int num){
        ofstream outfile;
        outfile.open("/home/nirvan/user1.txt");
        time_t curr_time;
	curr_time = time(NULL);

	tm *tm_local = localtime(&curr_time);
	int discount=0,priceafterdis=0,i;
        cout<<"***WElCOME TO BHATBHATENI SUPERMARKET****"<<endl<<"-----------------------------"<<endl<<"---------------------------"<<endl;
	for(i=0;i<num;i++){
                if(totalprice[i]>600)
                {
                discount=0.25*totalprice[i];
                priceafterdis=totalprice[i]-discount;
                }
                else if(totalprice[i]>200 && totalprice[i]<400){
                                discount=0.15*totalprice[i];
                priceafterdis=totalprice[i]-discount;
                }
                else if(totalprice[i]>100 && totalprice[i]<200){
                        discount=0.05*totalprice[i];
                        priceafterdis=totalprice[i]-discount;
                }
                else{
                                discount=0;
                                priceafterdis=totalprice[i]-discount;

                }
	
		outfile<<endl<<"For customer: "<<custid[i]<<"\t\t\tTime: "<< tm_local->tm_hour << ":" << tm_local->tm_min << ":" << tm_local->tm_sec<<endl<<"-----------------------------------------------"<<endl<<"---------------------------------------------------"<<endl;
         	cout<<endl<<"For customer: "<<custid[i]<<"\t\t\tTime: "<< tm_local->tm_hour << ":" << tm_local->tm_min << ":" << tm_local->tm_sec<<endl<<"----------------------------------------------"<<endl<<"-----------------------------------------------------"<<endl;
                cout<<endl;
		outfile<<endl;
		outfile<<"Total price: "<<totalprice[i]<<endl;
                outfile<<"Discount price: "<<discount<<endl;
                outfile<<"Price after discount: "<<priceafterdis<<endl;
		cout<<"Total price: "<<totalprice[i]<<endl;
                cout<<"Discount price: "<<discount<<endl;
                cout<<"Price after discount: "<<priceafterdis<<endl;


 

	}
	outfile.close();
}
