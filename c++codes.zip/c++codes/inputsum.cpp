#include<iostream>
using namespace std;

int main()
{
	int num1;
	int num2;
	int sum=0;
	
	cout<<"Enter first number :";
	cin>>num1;

	cout<<"Enter second number :";
	cin>>num2;

	sum=num1+num2;

	cout<<"Sum of "<<num1<<" & "<<num2<<" is :"<<sum;
	return 0;
}
