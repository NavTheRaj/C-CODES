#include<iostream>
#include<math.h>
using namespace std;

int main(){
	int num=0,i,sum=0;
	cout<<"Enter the limit number: ";
	cin>>num;
	for(i=1;i<(num+1);i++)
        {
         sum=sum+pow(i,2);
	}
	cout<<"The total is : "<<sum;
}
